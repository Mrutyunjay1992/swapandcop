import React from "react";
import { Item } from "native-base";
import { Picker } from '@react-native-community/picker';
import { StyleSheet } from "react-native";
import { THEME } from "../../themes/default";


const DropDown = ({ placeholder, style }) => {
    return (
        <Item style={{ ...styles.container, ...style }}>
            <Picker
                selectedValue={placeholder}
                style={{ height: 55, width: '100%', color: THEME.COLORS.GREY_LIGHT }}
                onValueChange={(itemValue, itemIndex) =>
                    this.setState({ language: itemValue })
                }>
                <Picker.Item label={placeholder} value={placeholder} />
            </Picker>
        </Item>
    )
}


const styles = StyleSheet.create({
    container: {
        backgroundColor: THEME.COLORS.WHITE,
        width: '100%',
        borderRadius: 10,
        justifyContent: 'space-between',
        borderTopWidth: 1,
        borderLeftWidth: 1,
        borderRightWidth: 1,
        borderColor: THEME.COLORS.GREY,
        marginTop: 20
    }
})
export default DropDown;