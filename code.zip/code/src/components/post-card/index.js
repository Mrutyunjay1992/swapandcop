import React from "react";
import { View, Text, StyleSheet, Dimensions, FlatList, Share } from "react-native";
import { Thumbnail, Icon } from "native-base";
import { AirbnbRating } from 'react-native-ratings';
import { SliderBox } from "react-native-image-slider-box";
import { THEME } from "../../themes/default";
import Button from "../button";
import { STRING } from "../../utils/strings";
import { TouchableHighlight } from "react-native-gesture-handler";


const VarientItemRender = (props) => {
    return (
        <View style={{ flex: 1, width: '50%', marginTop: 15, flexDirection: 'row' }}>
            <Icon type="AntDesign" name="check" style={{ color: THEME.COLORS.GREY_LIGHT, fontSize: 20 }} />
            <Text style={{ fontSize: 15, marginLeft: 10, color: THEME.COLORS.GREY }}>{props.item.title}</Text>
        </View>
    )
}


const PostCard = (props) => {

    const onShare = async () => {
        try {
            const result = await Share.share({
                message:
                    'Share your Choice',
            });
            if (result.action === Share.sharedAction) {
                if (result.activityType) {
                    // shared with activity type of result.activityType
                } else {
                    // shared
                }
            } else if (result.action === Share.dismissedAction) {
                // dismissed
            }
        } catch (error) {
            alert(error.message);
        }
    };

    return (
        <View style={styles.container}>
            <>
                {/* header START */}
                <TouchableHighlight onPress={props.onPostPress} underlayColor={false} style={styles.section_header}>
                    <>
                        <View style={styles.header_avatar}>
                            <Thumbnail style={styles.thumbnail} source={require("./../../assets/images/user-placeholder.png")} />
                        </View>
                        <View style={styles.header_username_section}>
                            <View style={styles.header_username}>
                                <View style={{ flexDirection: 'row' }}>
                                    <Text style={styles.username}>Pavanwind</Text>
                                    <AirbnbRating
                                        count={5}
                                        reviews={["Terrible", "Bad", "Meh", "OK", "Good"]}
                                        defaultRating={5}
                                        size={10}
                                        showRating={false}
                                        selectedColor={THEME.COLORS.GREY}
                                    />
                                </View>
                                <Text style={styles.location}>Atlanta,GA</Text>
                            </View>
                            <View>
                                <Icon style={{ fontSize: 30, color: THEME.COLORS.GREY_LIGHT }} type={'MaterialIcons'} name={'more-horiz'} />
                            </View>
                        </View>
                    </>
                </TouchableHighlight>
                {/* header END */}


                {/* Slider START */}
                <TouchableHighlight onPress={props.onPostPress} underlayColor={false} style={styles.section_slider}>
                    <>
                        <SliderBox
                            images={props.images}
                            inactiveDotColor="#90A4AE"
                            paginationBoxVerticalPadding={20}
                            resizeMethod={'resize'}
                            resizeMode={'cover'}
                            ImageComponentStyle={{ borderRadius: 15, width: '97%', marginTop: 5, height: 300, width: Dimensions.get('window').width - 30 }}
                            imageLoadingColor="#2196F3"
                        />
                        {/* Count Image START*/}
                        <Text style={styles.count}>1/{props.images.length}</Text>
                        {/* Count Image END*/}
                        {/* star Icon START */}
                        <View style={styles.right_star}>
                            <Icon type="Entypo" name={'star'} style={{ color: THEME.COLORS.WHITE }} />
                        </View>
                        {/* star Icon END */}
                    </>
                </TouchableHighlight>
                {/* Slider START */}

                <View style={styles.section_detail}>
                    <View style={styles.desc}>
                        <Text style={styles.detail_text}>Travis Scott x air Max 270 React Eng 'Cactus Trails'</Text>
                    </View>
                    <View style={styles.rate}>
                        <Text style={styles.detail_text}>$500/ea</Text>
                    </View>
                </View>

                {/* varient View START */}
                <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }}>
                    <FlatList
                        data={props.varients}
                        renderItem={(p) => <VarientItemRender {...p} />}
                        keyExtractor={(item, index) => index}
                        numColumns={2}
                        key={2}
                    />
                    <Icon onPress={() => onShare()} type="Entypo" name="forward" style={{ color: THEME.COLORS.GREY_LIGHT }} />
                </View>
                {/* varient View END */}

                <View style={styles.button_container}>
                    <Button
                        text={STRING.LETS_SWAP}
                        iconStyle={{ color: THEME.COLORS.WHITE, position: "absolute", right: 10 }}
                        iconType={'AntDesign'}
                        iconName={'arrowright'}
                        textStyle={styles.socail_media_btn_text}
                        onPress={() => props.onBtnPress()}
                    />
                </View>
            </>
        </View>
    )
}


const styles = StyleSheet.create({
    container: {
        flex: 1,
        marginTop: 30
    },
    thumbnail: {
        width: 50,
        height: 50
    },
    header_username_section: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center'
    },
    section_header: {
        flexDirection: 'row'
    },
    header_avatar: {
        // borderWidth: 1
    },
    header_username: {
        marginLeft: 15
    },
    username: {
        fontSize: 18,
        fontWeight: 'bold',
        color: THEME.COLORS.GREY,
        marginRight: 15
    },
    location: {
        fontSize: 15,
        fontWeight: '500',
        color: THEME.COLORS.GREY
    },
    section_slider: {
        flex: 1,
        marginTop: 15
    },
    count: { position: 'absolute', left: 15, top: 15, backgroundColor: THEME.COLORS.GREY_LIGHT, padding: 4, borderRadius: 10, color: THEME.COLORS.WHITE },
    right_star: { position: 'absolute', right: 15, top: 15, backgroundColor: THEME.COLORS.GREY_LIGHT, padding: 4, borderRadius: 100 / 2 },
    section_detail: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginTop: 10
    },
    desc: {
        width: '70%'
    },
    rate: {
        width: '30%',
        alignItems: 'flex-end'
    },
    detail_text: {
        fontSize: 20,
        fontWeight: 'bold',
        color: THEME.COLORS.GREY
    },
    button_container: {
        marginTop: 20
    }
})

export default PostCard;