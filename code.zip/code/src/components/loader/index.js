import React from "react";
import AnimatedLoader from "react-native-animated-loader";
import { StyleSheet } from "react-native";


const Loader = () => {
    return (
        <AnimatedLoader
            visible={true}
            overlayColor="rgba(0,0,0,0)"
            animationStyle={styles.lottie}
            animationType={'fade'}
            speed={2}
            source={require("./../../../assets/loader/loader.json")}
        />
    )
}

const styles = StyleSheet.create({
    lottie: {
        width: 100,
        height: 100
    }
});


export default Loader;