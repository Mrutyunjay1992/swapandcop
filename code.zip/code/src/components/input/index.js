import React from "react";
import { View, Text, TextInput, StyleSheet } from "react-native";
import { THEME } from "../../themes/default";
import { Icon } from "native-base";

const Input = ({ style, iconType, iconName, input, right, iconStyle, onIconPress }) => {

    return (
        <View style={{ ...styles.container, ...style }}>
            {
                iconType && !right &&
                <Icon onPress={onIconPress} type={iconType} name={iconName} style={{ color: THEME.COLORS.GREY_LIGHT, ...iconStyle }} />
            }
            <TextInput
                style={styles.input}
                {...input}
            />
            {
                iconType && right &&
                <Icon onPress={onIconPress} type={iconType} name={iconName} style={{ color: THEME.COLORS.GREY_LIGHT, ...iconStyle }} />
            }
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        borderWidth: 1,
        borderColor: THEME.COLORS.GREY_LIGHT,
        borderRadius: 10,
        height: 55,
        paddingLeft: 15,
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: 20
    },
    input: {
        padding: 10,
        justifyContent: 'center',
        width: '90%'
    }
})

export default Input;