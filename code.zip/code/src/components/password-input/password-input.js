import React, { useState } from "react";
import { View, Text, TextInput, StyleSheet, TouchableOpacity } from "react-native";
import { THEME } from "../../themes/default";
import { Icon } from "native-base";

const PasswordInput = (props) => {
    const [showPass, setShowPass] = useState(true);

    const viewPasswordHandler = () => {
        setShowPass(!showPass)
        console.log(" ==== call ==== ")
    }

    return (
        <View style={styles.container}>
            {
                props.iconType &&
                <Icon type={props.iconType} name={props.iconName} style={{ color: THEME.COLORS.GREY_LIGHT }} />
            }
            <TextInput
                style={styles.input}
                secureTextEntry={showPass}
                {...props.input}
            />
            {
                showPass ?
                    <TouchableOpacity onPress={() => viewPasswordHandler()}>
                        <Icon type={"Entypo"} name="eye-with-line" style={{ color: THEME.COLORS.GREY_LIGHT }} />
                    </TouchableOpacity>
                    :
                    <TouchableOpacity onPress={() => viewPasswordHandler()}>
                        <Icon type={"Entypo"} name="eye" style={{ color: THEME.COLORS.GREY_LIGHT }} />
                    </TouchableOpacity>

            }
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        borderWidth: 1,
        borderColor: THEME.COLORS.GREY_LIGHT,
        borderRadius: 10,
        height: 55,
        paddingLeft: 15,
        flexDirection: 'row',
        alignItems: 'center'
    },
    input: {
        padding: 10,
        justifyContent: 'center',
        width: '80%'
    }
})

export default PasswordInput;