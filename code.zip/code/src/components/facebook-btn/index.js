import React from "react";
import { View, Text, Dimensions } from "react-native";
var { FBLogin, FBLoginManager } = require('react-native-facebook-login');

const { width } = Dimensions.get('window')
const FacebookBtn = () => {
    return (
        <FBLogin style={{ width: '98%', marginTop: 6 }} />
    )
}

export default FacebookBtn;