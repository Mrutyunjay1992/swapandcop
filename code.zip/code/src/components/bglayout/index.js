import React from "react"
import {
    StyleSheet,
    ImageBackground,
    Dimensions
} from "react-native";

const image = require('./../../assets/images/bg.png');

const { height } = Dimensions.get('window')
const ImageLayout = ({ children, customStyle }) => {
    return (
        <ImageBackground source={image} style={{...styles.image, ...customStyle}}>
            {children}
        </ImageBackground>
    )
}
 

const styles = StyleSheet.create({
    image: {
        flex: 1,
        height: height,
        resizeMode: "cover"
    }
})
export default ImageLayout;


