import React from "react";
import { View, Text, StyleSheet } from "react-native";
import { THEME } from "../../themes/default";

const Logo = (props) => {
    return (
        <View style={{ ...styles.container, ...props.containerStyle }}>
            <Text style={{ ...styles.text, ...props.textStyle }}>S&C</Text>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: THEME.COLORS.GREY,
        width: 83,
        height: 83,
        borderRadius: 10,
        justifyContent: "center",
        alignItems: 'center'
    },
    text: {
        color: THEME.COLORS.WHITE,
        fontWeight: 'bold',
        fontSize: 20
    }
})

export default Logo;