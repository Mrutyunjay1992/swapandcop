import React from "react";
import { Text, TouchableOpacity, StyleSheet } from "react-native";
import { THEME } from "../../themes/default";
import { Icon } from "native-base";
import LinearGradient from 'react-native-linear-gradient';
import { TouchableHighlight } from "react-native-gesture-handler";

const Button = (props) => {
    const colors = props.colors ? props.colors : THEME.COLORS.GOOGLE_BTN;

    return (
        <TouchableHighlight onPress={() => props.onPress()} style={props.containerStyle} underlayColor={false}>
            <LinearGradient onPress={props.onPress} colors={colors} style={{ ...styles.container }}>
                <Text style={{ ...styles.text, ...props.textStyle }}>{props.text}</Text>
                {
                    props.iconType &&
                    <Icon type={props.iconType} name={props.iconName} style={{ ...props.iconStyle }} />
                }
            </LinearGradient>
        </TouchableHighlight>
    )
}

const styles = StyleSheet.create({
    container: {
        height: 58,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 10,
        flexDirection: 'row'
    },
    text: {
        color: THEME.COLORS.WHITE,
        fontSize: 16,
        fontWeight: 'bold'
    }
})
export default Button;