import React from "react";
import { View, Text, StyleSheet } from "react-native";
import { THEME } from "../../themes/default";
import { STRING } from "../../utils/strings";


const UserDetail = () => {
    return (
        <View style={styles.container}>
            <View style={styles.section}>
                <Text style={styles.count}>865</Text>
                <Text style={styles.title}>{STRING.SHOES}</Text>
            </View>
            <View style={styles.section}>
                <Text style={styles.count}>10K</Text>
                <Text style={styles.title}>{STRING.FOLLOWERS}</Text>
            </View>
            <View style={styles.section}>
                <Text style={styles.count}>36k</Text>
                <Text style={styles.title}>{STRING.FOLLOWING}</Text>
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        marginLeft: 15,
        flex: 1,
        height: 80,
        flexDirection: 'row',
        justifyContent: 'space-evenly'
    },
    section: {
        justifyContent: 'center',
        alignItems: 'center'
    },
    count: {
        fontSize: 25,
        justifyContent: 'center',
        color: THEME.COLORS.GREY,
        fontWeight: 'bold'
    },
    title: {
        color: THEME.COLORS.GREY,
        fontSize: 15,
        fontWeight: '400'
    }

})


export default UserDetail;