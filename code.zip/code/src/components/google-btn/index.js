import React from "react";
import { View, Text } from "react-native";
import { GoogleSignin, GoogleSigninButton } from 'react-native-google-signin';


const GoogleBtn = () => {
    return (
        <GoogleSigninButton
            style={{ width: '50%', height: 49 }}
            size={GoogleSigninButton.Size.Standard}
            color={GoogleSigninButton.Color.Dark}
        />
    )
}

export default GoogleBtn;