import React from "react";
import { View, Text, StyleSheet, Image, TouchableHighlight } from "react-native";
import { THEME } from "../../themes/default";
import { STRING } from "../../utils/strings";
import { Icon, Thumbnail } from "native-base";


const ListPost = (props) => {
    return (
        <TouchableHighlight onPress={props.onPress} style={styles.container} underlayColor={false}>
            <>
                <View style={styles.section_image}>
                    <Image style={styles.image} source={require("./../../assets/images/placeholder.jpeg")} />
                </View>
                <View style={styles.detail_secion}>
                    <View style={{ flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }}>
                        <Text style={styles.message_detail}>Travi scott X air Max 270 react eng cactus trails</Text>
                    </View>
                    <Text style={styles.message_detail}>$500</Text>
                    <View style={styles.user_container}>
                        <Thumbnail style={styles.avatar} source={require("./../../assets/images/user-placeholder.png")} />
                        <View style={styles.avatar_container}>
                            <Text style={{ ...styles.message_detail, fontSize: 16 }}>GOATKicks</Text>
                            <Text style={styles.total_message}>Atlanta, GA</Text>
                        </View>
                    </View>
                </View>

            </>
        </TouchableHighlight>
    )
}

const styles = StyleSheet.create({
    user_container: {
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: 10
    },
    avatar: {
        width: 30,
        height: 30
    },
    avatar_container: {
        marginLeft: 10
    },
    container: {
        flex: 1,
        padding: 10,
        flexDirection: 'row',
        backgroundColor: '#fff',
        borderRadius: 10,
        marginTop: 10
    },
    section_image: {
        alignItems: 'center',
        justifyContent: 'center',
        width: '30%'
    },
    icon_section: {
        justifyContent: 'center',
        alignItems: 'center',
        marginLeft: 10
    },
    image: {
        width: 110,
        height: 110,
        borderRadius: 10
    },
    badge_section: {
        position: 'absolute',
        right: -4,
        top: -4,
        backgroundColor: THEME.COLORS.GREY,
        borderRadius: 50,
        width: 15,
        height: 15,
        justifyContent: 'center',
        alignItems: 'center'
    },
    detail_secion: {
        flex: 1,
        flexDirection: 'column',
        marginLeft: 20,
        height: '90%'
    },
    message_detail: {
        flex: 1,
        flexWrap: 'wrap',
        fontSize: 20,
        fontWeight: 'bold',
        color: THEME.COLORS.GREY
    },
    total_message: {
        justifyContent: 'center',
        alignItems: 'center',
        fontSize: 16,
        color: THEME.COLORS.GREY
    }
})
export default ListPost;