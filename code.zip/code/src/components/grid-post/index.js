import React from "react";
import { View, Text, StyleSheet, Image } from "react-native";



const GridPost = (props) => {

    return (
        <View style={styles.container}>
            <Image source={require("./../../assets/images/placeholder.jpeg")} style={styles.image} />
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        width: '50%',
        alignItems: 'center',
        padding: 20
    },
    image: {
        width: 150,
        resizeMode: 'cover',
        height: 150,
        borderRadius: 10
    }
})

export default GridPost;