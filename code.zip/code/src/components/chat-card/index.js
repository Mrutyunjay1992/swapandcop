import React from "react";
import { View, Text, StyleSheet, Image, TouchableHighlight } from "react-native";
import { THEME } from "../../themes/default";
import { STRING } from "../../utils/strings";
import { Icon } from "native-base";


const ChatCard = (props) => {
    return (
        <TouchableHighlight onPress={props.onPress} style={styles.container} underlayColor={false}>
            <>
                <View style={styles.section_image}>
                    <Image style={styles.image} source={require("./../../assets/images/user-placeholder.png")} />
                    {
                        props.isindicated &&
                        <View style={styles.badge_section} />
                    }
                </View>
                <View style={styles.detail_secion}>
                    <View style={{ flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }}>
                        <Text style={styles.message_detail}>JShmoe</Text>
                        <Text style={{ color: THEME.COLORS.GREY }}>4:20 PM</Text>
                    </View>
                    <Text style={styles.total_message}>Yo, I am interested in those Chunky Dunky. let's Swap</Text>
                </View>

            </>
        </TouchableHighlight>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 10,
        flexDirection: 'row',
        backgroundColor: '#fff',
        borderRadius: 10,
        marginTop: 10
    },
    icon_section: {
        justifyContent: 'center',
        alignItems: 'center',
        marginLeft: 10
    },
    image: {
        width: 80,
        height: 80,
        borderRadius: 50
    },
    badge_section: {
        position: 'absolute',
        right: -4,
        top: -4,
        backgroundColor: THEME.COLORS.GREY,
        borderRadius: 50,
        width: 15,
        height: 15,
        justifyContent: 'center',
        alignItems: 'center'
    },
    detail_secion: {
        flex: 1,
        flexDirection: 'column',
        marginLeft: 20,
        height: '90%'
    },
    message_detail: {
        flex: 1,
        flexWrap: 'wrap',
        fontSize: 20,
        fontWeight: 'bold',
        color: THEME.COLORS.GREY
    },
    total_message: {
        justifyContent: 'center',
        alignItems: 'center',
        fontSize: 16,
        color: THEME.COLORS.GREY
    }
})
export default ChatCard;