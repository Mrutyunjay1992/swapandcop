import React from "react";
import { TouchableHighlight } from "react-native-gesture-handler";
import { Icon } from "native-base";
import { Text, StyleSheet } from "react-native";
import { THEME } from "../../themes/default";


const CheckBox = (props) => {
    return (
        <TouchableHighlight onPress={props.onPress} underlayColor={false} style={{ ...styles.container, ...props.style }}>
            {
                props.status === true ?
                    <Icon style={styles.icon} type="AntDesign" name="check" />
                    :
                    <Icon style={styles.icon} type="AntDesign" name="minus" />
            }
        </TouchableHighlight>
    )
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: THEME.COLORS.GREY,
        padding: 5,
        borderRadius: 50,
        justifyContent: 'center',
        alignItems: 'center'
    },
    icon: {
        color: THEME.COLORS.WHITE,
        fontSize: 20,
        fontWeight: 'bold'
    }
})

export default CheckBox;