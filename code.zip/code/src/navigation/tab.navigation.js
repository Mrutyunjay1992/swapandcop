import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator, HeaderTitle } from '@react-navigation/stack';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { Text, StyleSheet, View } from "react-native";
import HomeScreen from '../screens/private/home';
import { Icon, Thumbnail } from 'native-base';
import { THEME } from '../themes/default';
import Splash from '../screens/public/splash';
import LoginScreen from '../screens/public/login';
import { TouchableHighlight } from 'react-native-gesture-handler';
import ProfileScreen from '../screens/private/profile/profile';
import TrendingScreen from '../screens/private/trending';
import CreatePostScreen from '../screens/private/create-post';
import InboxScreen from '../screens/private/inbox';
import ChatListScreen from '../screens/private/chat-list';
import ChatBox from '../screens/private/chat-screen';
import SinglePost from '../screens/private/single-post';
import { STRING } from '../utils/strings';
import SearchScreen from '../screens/private/search-screen';
import SavedSearches from '../screens/private/saved-searches';
import SaveSearch from '../screens/private/save-search';



const Tab = createBottomTabNavigator();


const tabScreens = (props) => {
  return (
    <Tab.Navigator
      tabBarOptions={{
        activeTintColor: '#ce1414',
        inactiveTintColor: THEME.COLORS.GREY,
      }}
    >
      <Tab.Screen
        name="Home"
        component={HomeScreen}
        options={{
          tabBarIcon: ({ focused, color, size }) => {
            return <Icon type="Entypo" name="home" size={size} style={{ ...styles.tabIcon, color: color }} />;
          },
          title: ""
        }}
      />
      <Tab.Screen
        name="trending"
        component={TrendingScreen}
        options={{
          tabBarIcon: ({ focused, color, size }) => {
            return <Icon type="FontAwesome5" name="fire" size={size} style={{ ...styles.tabIcon, color: color }} />;
          },
          title: ""
        }}
      />
      <Tab.Screen
        name="inbox"
        component={InboxScreen}
        options={{
          tabBarIcon: ({ focused, color, size }) => {
            return <Icon type="Entypo" name="chat" size={size} style={{ ...styles.tabIcon, color: color }} />;
          },
          title: "",
          tabBarBadge: 3,
        }}
      />
      <Tab.Screen
        name="createPost"
        component={CreatePostScreen}
        options={{
          tabBarIcon: ({ focused, color, size }) => {
            return <Icon type="AntDesign" name="pluscircle" size={size} style={{ ...styles.tabIcon, color: color }} />;
          },
          title: ""
        }}
      />
    </Tab.Navigator>
  )
}

const TabStack = createStackNavigator();

function getHeaderTitle(route) {
  const routeName = route.state
    ? route.state.routes[route.state.index].name
    : route.params?.screen || 'Profile';

  switch (routeName) {
    case 'inbox':
      return 'Inbox';
    case 'createPost':
      return 'Create Post';
    case 'trending':
      return 'Whats New';
    case 'Home':
      return 'Home';
    default:
      return 'Home'
  }
}


export default function TabNavigation(props) {
  return (
    <NavigationContainer>
      <TabStack.Navigator
        initialRouteName="splash"
        headerMode="screen"
      >
        <TabStack.Screen
          name="splash"
          component={Splash}
          options={{
            headerShown: false
          }}
        />

        <TabStack.Screen
          name="login"
          component={LoginScreen}
          options={{
            headerShown: false
          }}
        />

        <TabStack.Screen
          name="HomeStack"
          component={tabScreens}
          options={({ navigation, route }) => ({
            headerShown: true,
            headerStatusBarHeight: 0,
            headerRight: () => (
              <TouchableHighlight onPress={() => navigation.navigate('profile')} underlayColor={false}>
                <Icon type="AntDesign" name="user" style={styles.headerIcon} />
              </TouchableHighlight>
            ),
            headerTitle: () => <Text style={styles.profile_title}>{getHeaderTitle(route)}</Text>,
            headerLeft: () => {
              const routeName = route.state
                ? route.state.routes[route.state.index].name
                : route.params?.screen || 'Home';
              return (
                <>
                  {
                    routeName === 'Home' ?
                      <TouchableHighlight onPress={() => navigation.navigate('searchscreen')} underlayColor={false}>
                        <Icon type="Fontisto" name="equalizer" style={styles.headerIcon} />
                      </TouchableHighlight>
                      :
                      <TouchableHighlight onPress={() => navigation.goBack()} underlayColor={false}>
                        <Icon type="AntDesign" name="left" style={styles.headerIcon} />
                      </TouchableHighlight>
                  }

                </>
              )
            },
            headerLeftContainerStyle: {
              marginLeft: 15
            },
            headerRightContainerStyle: {
              marginRight: 15
            }
          })}
        />
        <TabStack.Screen
          name="profile"
          component={ProfileScreen}
          options={({ navigation, route }) => ({
            headerTitle: () => <Text style={styles.profile_title}>GOATKicks</Text>
          })}
        />

        <TabStack.Screen
          name="chatList"
          component={ChatListScreen}
          options={({ navigation, route }) => ({
            headerTitle: () => <Text style={styles.profile_title}>Inbox</Text>
          })}
        />

        <TabStack.Screen
          name="chatscreen"
          component={ChatBox}
          options={({ navigation, route }) => ({
            headerTitle: () => (
              <View style={{ flex: 1, flexDirection: 'row' }}>
                <Thumbnail source={require("./../assets/images/user-placeholder.png")} />
                <View style={{ flex: 1, marginLeft: 20, justifyContent: 'center' }}>
                  <Text style={{ ...styles.profile_title, color: THEME.COLORS.WHITE, fontSize: 20 }}>ShandongG</Text>
                  <Text style={{ ...styles.profile_title, color: THEME.COLORS.WHITE, fontSize: 18, fontWeight: '400' }}>Atlanta, GA</Text>
                </View>
              </View>
            ),
            headerStyle: {
              backgroundColor: THEME.COLORS.GREY,
              height: 80
            },
          })}
        />

        <TabStack.Screen
          name="singlepost"
          component={SinglePost}
          options={({ navigation, route }) => ({
            headerTitle: () => <Text style={styles.profile_title}>{STRING.SWAP_AND_COP}</Text>
          })}
        />

        <TabStack.Screen
          name="searchscreen"
          component={SearchScreen}
          options={{
            headerShown: false
          }}
        />

        <TabStack.Screen
          name="savesearches"
          component={SavedSearches}
          options={{
            headerShown: true,
            headerTitle: () => <Text style={styles.profile_title}>{STRING.SAVED_SEARCHES}</Text>
          }}
        />

        <TabStack.Screen
          name="savesearch"
          component={SaveSearch}
          options={{
            headerShown: true,
            headerTitle: () => <Text style={styles.profile_title}>{STRING.SAVE_SEARCH}</Text>
          }}
        />

      </TabStack.Navigator>
    </NavigationContainer>
  );
}


const styles = StyleSheet.create({
  headerIcon: {
    fontSize: 25,
    color: THEME.COLORS.GREY
  },
  tabIcon: {
    color: THEME.COLORS.GREY
  },
  profile_title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: THEME.COLORS.GREY
  }
})