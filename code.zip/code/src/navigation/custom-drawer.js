import React from "react";
import ImageLayout from "../components/bglayout";
import { View, Dimensions, Text } from "react-native";

const { height, width } = Dimensions.get('window')
const Drawer = () => {
    return (
        <ImageLayout>
            <View style={{ flex: 1, height: height, width: width, position: 'absolute', zIndex: 9, top: 0 }}>
                <Text>Hey</Text>
            </View>
        </ImageLayout>
    )
}

export default Drawer;