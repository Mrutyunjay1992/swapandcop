export const THEME = {
    COLORS: {
        GREY: '#666',
        GREY_LIGHT: '#66666661',
        WHITE: '#fff',
        BLACK: '#000',
        FACEBOOK_BTN: ["#006df7", "#006df7", "#113e77"],
        GOOGLE_BTN: ["#ce1414", "#ce1414", "#6f0505"]
    }
}