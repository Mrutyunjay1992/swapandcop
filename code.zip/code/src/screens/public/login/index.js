import React, { Component } from "react";
import { View, Text, ScrollView, Keyboard } from "react-native";
import { styles } from "./style";
import Logo from "../../../components/logo";
import { STRING } from "../../../utils/strings";
import Input from "../../../components/input";
import { Item } from "native-base";
import PasswordInput from "../../../components/password-input/password-input";
import Button from "../../../components/button";
import { THEME } from "../../../themes/default";
import ImageLayout from "../../../components/bglayout";
import GoogleBtn from "../../../components/google-btn";
import FacebookBtn from "../../../components/facebook-btn";

class LoginScreen extends Component {

    state = {
        keyBoard: false
    }

    componentDidMount() {
        const ref = this;
        this.keyboardDidShowListener = Keyboard.addListener('keyboardDidShow', () => {
            ref.setState({
                keyBoard: true
            })
        });
        this.keyboardDidHideListener = Keyboard.addListener('keyboardDidHide', () => {
            ref.setState({
                keyBoard: false
            })
        });
    }

    componentWillUnmount() {
        this.keyboardDidShowListener.remove();
        this.keyboardDidHideListener.remove();
    }


    onLoginHandler = () => {
        console.log(" ==== ", this.props)
        this.props.navigation.replace('HomeStack')
    }

    render() {
        const { keyBoard } = this.state;
        return (
            <View style={styles.container}>
                <ImageLayout>
                    <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
                        <View style={styles.section_logo}>
                            <Logo />
                        </View>
                        <View style={styles.section_login_text_container}>
                            <Text style={styles.section_login_text}>{STRING.LOGIN}</Text>
                        </View>
                        <View style={styles.section_form}>
                            <Item style={styles.section_form_item}>
                                <Input input={{ placeholder: STRING.NAME }} iconType={'AntDesign'} iconName={'user'} />
                            </Item>
                            <Item style={styles.section_form_item}>
                                <PasswordInput input={{ placeholder: STRING.PASSWORD }} iconType={'AntDesign'} iconName={'lock'} />
                            </Item>
                        </View>
                        <View style={styles.section_signin_btn}>
                            <Button onPress={this.onLoginHandler} text={STRING.SINGIN} iconStyle={{ color: THEME.COLORS.WHITE, position: "absolute", right: 10 }} iconType={'AntDesign'} iconName={'arrowright'} />
                        </View>
                        <View style={styles.social_media_btn_container}>
                            <GoogleBtn />
                            <FacebookBtn />
                        </View>
                        <View style={styles.section_forgot_password}>
                            <Text style={styles.forgot_password_text}>{STRING.FORGOT_PASSWORD}</Text>
                        </View>
                        {
                            !keyBoard &&
                            <View style={styles.create_ac_btn_container}>
                                <Button
                                    containerStyle={styles.create_new_ac}
                                    text={STRING.CREATE_AN_ACCOUNT}
                                    iconStyle={{ color: THEME.COLORS.WHITE, position: "absolute", right: 10 }}
                                    iconType={'AntDesign'}
                                    iconName={'arrowright'}
                                    textStyle={styles.socail_media_btn_text}
                                    onPress={() => true}
                                />
                            </View>
                        }
                    </ScrollView>
                </ImageLayout>
            </View>
        )
    }
}

export default LoginScreen;