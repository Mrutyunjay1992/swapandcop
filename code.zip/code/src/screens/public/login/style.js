import { StyleSheet } from "react-native";
import { THEME } from "../../../themes/default";
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
export const styles = StyleSheet.create({
    container: {
        // flex: 1
        height: '100%'
    },
    section_logo: {
        paddingLeft: 30,
        marginTop: hp('5')
    },
    section_login_text_container: {
        marginTop: hp('3'),
        paddingLeft: 30
    },
    section_login_text: {
        fontSize: 32,
        fontWeight: 'bold',
        color: THEME.COLORS.GREY
    },
    section_form: {
        marginLeft: 20,
        marginRight: 20,
        marginTop: 30
    },
    section_form_item: {
        marginTop: 15
    },
    section_signin_btn: {
        marginLeft: 20,
        marginRight: 20,
        marginTop: 30
    },
    social_media_btn_container: {
        flexDirection: 'row',
        marginLeft: 20,
        marginRight: 20,
        marginTop: 10,
        justifyContent: 'space-between'
    },
    socail_media_btn: {
        backgroundColor: THEME.COLORS.WHITE,
        width: '45%'
    },
    socail_media_btn_text: {
        color: THEME.COLORS.WHITE
    },
    section_forgot_password: {
        marginLeft: 20,
        marginRight: 20,
        marginTop: 20,
        marginBottom: 20,
        justifyContent: 'center',
        alignItems: 'center'
    },
    forgot_password_text: {
        color: THEME.COLORS.GREY,
        fontSize: 17,
        fontWeight: '600'
    },
    create_ac_btn_container: {
        position: 'absolute',
        bottom: 10,
        width: "100%",
        paddingLeft: 20,
        paddingRight: 20
    },
    create_new_ac: {
        backgroundColor: THEME.COLORS.WHITE
    }

})