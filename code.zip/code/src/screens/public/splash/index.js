import React, { Component } from "react";
import { View, Text, StyleSheet } from "react-native";
import ImageLayout from "../../../components/bglayout";
import Logo from "../../../components/logo";
import { THEME } from "../../../themes/default";
import AnimatedLoader from "react-native-animated-loader";


class Splash extends Component {

    componentDidMount() {
        setTimeout(() => {
            this.props.navigation.replace('login')
        }, 4000)
    }

    render() {
        return (
            <ImageLayout>
                <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                    <Logo containerStyle={{ height: 150, width: 150 }} textStyle={{ fontSize: 30 }} />
                    <Text style={{ fontSize: 40, fontWeight: 'bold', marginTop: 100, color: THEME.COLORS.GREY }}>Swap & Crop</Text>
                    <AnimatedLoader
                        visible={true}
                        overlayColor="rgba(0,0,0,0)"
                        animationStyle={styles.lottie}
                        animationType={'fade'}
                        speed={2}
                        source={require("./../../../assets/loader/loader.json")}
                        containerStyle={styles.containerStyle}
                    />
                </View>
            </ImageLayout>
        )
    }
}

const styles = StyleSheet.create({
    lottie: {
        width: 100,
        height: 100
    },
    containerStyle: {
        position: 'absolute',
        bottom: 0,
        flex: 1,
        justifyContent: 'flex-end'
    }
});

export default Splash