import React, { Component } from "react";
import { View, Text, StyleSheet } from "react-native";
import { ChatScreen } from 'react-native-easy-chat-ui'
import { THEME } from "../../../themes/default";

class ChatBox extends Component {
    state = {
        messages: [
            {
                id: `1`,
                type: 'text',
                content: 'hello world',
                targetId: '12345678',
                chatInfo: {
                    avatar: require('../../../assets/images/user-placeholder.png'),
                    id: '12345678',
                    nickName: 'Test'
                },
                renderTime: true,
                sendStatus: 0,
                time: '1542006036549'
            },
            {
                id: `2`,
                type: 'text',
                content: 'hi/{se}',
                targetId: '12345678',
                chatInfo: {
                    avatar: require('../../../assets/images/user-placeholder.png'),
                    id: '12345678',
                    nickName: 'Test'
                },
                renderTime: true,
                sendStatus: 0,
                time: '1542106036549'
            },
            {
                id: `3`,
                type: 'image',
                content: {
                    uri: 'https://upload-images.jianshu.io/upload_images/11942126-044bd33212dcbfb8.jpg?imageMogr2/auto-orient/strip|imageView2/1/w/300/h/240',
                    width: 100,
                    height: 80,
                },
                targetId: '12345678',
                chatInfo: {
                    avatar: require('../../../assets/images/user-placeholder.png'),
                    id: '12345678',
                    nickName: 'Test'
                },
                renderTime: false,
                sendStatus: 0,
                time: '1542106037000'
            },
            {
                id: `4`,
                type: 'text',
                content: 'this is',
                targetId: '88886666',
                chatInfo: {
                    avatar: require('../../../assets/images/user-placeholder.png'),
                    id: '12345678'
                },
                renderTime: true,
                sendStatus: 0,
                time: '1542177036549'
            }
        ],
        // chatBg: require('../../source/bg.jpg'),
        inverted: false,  // require
        voiceHandle: true,
        currentTime: 0,
        recording: false,
        paused: false,
        stoppedRecording: false,
        finished: false,
        audioPath: '',
        voicePlaying: false,
        voiceLoading: false
    }

    sendMessage = (type, content, isInverted) => {
        console.log(type, content, isInverted, 'msg')
    }

    render() {
        return (
            <View style={{ flex: 1 }}>
                <View style={styles.lable_container}>
                    <Text style={styles.label}>
                        BEN & JERRY's X DUNK LOW SB 'CHUNKY DUNKY'
                        </Text>
                    <Text style={styles.rate}>$2,500</Text>
                </View>
                <ChatScreen
                    ref={(e) => this.chat = e}
                    messageList={this.state.messages}
                    androidHeaderHeight={80}
                    sendMessage={this.sendMessage}
                    rightMessageBackground={THEME.COLORS.GREY}
                    rightMessageTextStyle={{
                        color: THEME.COLORS.WHITE
                    }}
                    placeholder={'Enter your message'}
                    useVoice={false}
                />
            </View>
        )
    }
}


const styles = StyleSheet.create({
    lable_container: { height: 80, borderBottomColor: THEME.COLORS.GREY_LIGHT, borderBottomWidth: 1, flexDirection: 'row', justifyContent: 'space-between', paddingLeft: 20, paddingRight: 20, alignItems: 'center' },
    label: { fontSize: 18, fontWeight: 'bold', color: THEME.COLORS.GREY, width: '70%' },
    rate: { fontSize: 15, fontWeight: 'bold', color: THEME.COLORS.GREY, width: '30%', textAlign: 'right' }
})
export default ChatBox;