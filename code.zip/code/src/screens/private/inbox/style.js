import { StyleSheet } from "react-native"
import { THEME } from "../../../themes/default"

export const styles = StyleSheet.create({
    swipe_delete_container: {
        flex: 1,
        alignItems: 'flex-end',
        justifyContent: 'center',
        marginTop: 10,
        backgroundColor: THEME.COLORS.GREY,
        borderRadius: 10
    },
    container: {
        flex: 1,
        marginRight: 20,
        marginLeft: 20
    },
    section_search: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center'
    },
    section_list: {
        flex: 6,
        marginTop: 20
    }
})