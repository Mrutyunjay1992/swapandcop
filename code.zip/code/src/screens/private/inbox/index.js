import React, { Component } from "react";
import { View, Text, StyleSheet, RefreshControl } from "react-native";
import { SwipeListView } from 'react-native-swipe-list-view';
import { FlatList, TouchableHighlight } from "react-native-gesture-handler";
import ImageLayout from "../../../components/bglayout";
import Input from "../../../components/input";
import { THEME } from "../../../themes/default";
import InboxCard from "../../../components/inbox-card";
import { Icon } from "native-base";
import { styles } from "./style";

class InboxScreen extends Component {
    state = {
        listViewData: Array(20)
            .fill("")
            .map((_, i) => ({ key: `${i}`, text: `item #${i}` }))
    }
    render() {
        const { navigation } = this.props
        return (
            <ImageLayout>
                <View style={styles.container}>
                    <View style={styles.section_search}>
                        <Input
                            input={{ placeholder: 'Search Messages' }}
                            style={{ backgroundColor: THEME.COLORS.WHITE, paddingRight: 20 }}
                            iconType="AntDesign"
                            iconName="search1"
                            right={true}
                            onIconPress={() => alert("hey")}
                        />
                    </View>
                    <View style={styles.section_list}>
                        <SwipeListView
                            data={this.state.listViewData}
                            renderItem={(p) => <InboxCard {...p} isindicated={true} onPress={() => navigation.navigate('chatList')} />}
                            renderHiddenItem={(data, rowMap) => (
                                <View style={styles.swipe_delete_container}>
                                    <TouchableHighlight underlayColor={false} onPress={() => alert("hey")} style={{ flex: 1, justifyContent: 'center', alignItems: 'center', width: 75 }} >
                                        <>
                                            <Icon type="AntDesign" name="delete" style={{ color: THEME.COLORS.WHITE }} />
                                            <Text style={{ color: THEME.COLORS.WHITE }}>DELETE</Text>
                                        </>
                                    </TouchableHighlight>
                                </View>
                            )}
                            rightOpenValue={-75}
                            disableRightSwipe={true}
                            keyExtractor={(item, index) => index}
                            showsVerticalScrollIndicator={false}
                        />
                    </View>
                </View>
            </ImageLayout>
        )
    }
}


export default InboxScreen;