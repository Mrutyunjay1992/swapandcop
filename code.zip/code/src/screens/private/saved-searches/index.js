import React, { Component } from "react";
import { View, Text, StyleSheet, SectionList } from "react-native";
import ImageLayout from "../../../components/bglayout";
import { THEME } from "../../../themes/default";
import { Icon } from "native-base";


class SavedSearches extends Component {

    state = {
        data: [
            {
                title: "RECENT",
                data: ["Travis Scott X Air Max 270 React Eng", "Ben & Jerry X Dunk Low SB Chunky", "Yeezy Boost 700 Mnvn TripleBlack"]
            },
            {
                title: "BOOKMARKS",
                data: ["Most Wanted Grail Travis Scott x air max 270 React Eng", "Ben & Jerry X Dunk Low SB chukny Dunky", "Yeezy Boost 700 Mnvn TripleBlack"]
            }
        ]
    }

    Item = ({ title }) => (
        <View style={styles.item}>
            <Text style={styles.title}>{title}</Text>
            <Icon type="Entypo" name="bookmark" />
        </View>
    );

    render() {
        return (
            <ImageLayout>
                <View style={{ flex: 1, margin: 20 }}>
                    <SectionList
                        sections={this.state.data}
                        keyExtractor={(item, index) => item + index}
                        renderItem={({ item }) => this.Item({ title: item })}
                        renderSectionHeader={({ section: { title } }) => (
                            <Text style={styles.header}>{title}</Text>
                        )}
                        showsVerticalScrollIndicator={false}
                    />
                </View>
            </ImageLayout>
        )
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        marginTop: 20,
        marginHorizontal: 16
    },
    item: {
        padding: 20,
        marginVertical: 8,
        flexDirection: 'row',
        justifyContent: 'space-between',
        borderBottomColor: THEME.COLORS.GREY,
        borderBottomWidth: 0.5
    },
    header: {
        fontSize: 20,
        fontWeight: 'bold',
        color: THEME.COLORS.GREY
    },
    title: {
        fontSize: 17,
        width: '80%'
    }
});


export default SavedSearches;