import { THEME } from "../../../themes/default";

const { StyleSheet } = require("react-native");

export const styles = StyleSheet.create({
    container: {
        flex: 1,
        marginLeft: 15,
        marginRight: 15
    },
    actionbar_icon_btn: {
        padding: 10,
        borderWidth: 1,
        borderRadius: 10
    },
    actionbar_icon: {
        fontSize: 30,
        color: THEME.COLORS.GREY
    },
    swipe_delete_container: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'flex-end',
        justifyContent: 'flex-end',
        marginTop: 10,
        backgroundColor: THEME.COLORS.GREY_LIGHT,
        borderRadius: 10
    },
    star_btn_container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        width: 75
    },
    delete_btn_container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        width: 75,
        backgroundColor: THEME.COLORS.GREY
    },
})