import React, { Component } from "react";
import { View, Text, ScrollView } from "react-native";
import { TouchableHighlight, FlatList } from "react-native-gesture-handler";
import { SwipeListView } from "react-native-swipe-list-view";
import ImageLayout from "../../../components/bglayout";
import { styles } from "./style";
import PostCard from "../../../components/post-card";
import DropDown from "../../../components/dropDown";
import { Icon } from "native-base";
import { THEME } from "../../../themes/default";
import GridPost from "../../../components/grid-post";
import ListPost from "../../../components/list-post";


class HomeScreen extends Component {
    state = {
        images: [
            require("./../../../assets/images/shoes/adidas.jpg"),
            require("./../../../assets/images/shoes/air.jpg"),
            require("./../../../assets/images/shoes/puma.jpeg"),
        ],
        varient: [
            {
                title: "Multiple Pairs",
                selected: true
            },
            {
                title: "Greate Condition",
                selected: false
            },
            {
                title: "In Original Box",
                selected: false
            },
            {
                title: "Verified Authentic",
                selected: false
            }
        ],
        view: 'post'
    }

    onViewAction = (view) => {
        this.setState({
            view: view
        })
    }


    onBtnPress = () => {
        this.props.navigation.navigate('chatscreen')
    }

    onPostPress = () => {
        this.props.navigation.navigate('singlepost')
    }

    render() {
        return (
            <ImageLayout>
                <View style={styles.container}>
                    <View style={{ flexDirection: 'row' }}>
                        <DropDown placeholder="Sort" style={{ width: '50%' }} />
                        <View style={{ width: '50%', marginTop: 20, height: 55, flexDirection: 'row', justifyContent: 'space-evenly', alignItems: 'center' }}>
                            <TouchableHighlight underlayColor={false} onPress={() => this.onViewAction('post')} style={{ ...styles.actionbar_icon_btn, backgroundColor: this.state.view === 'post' ? THEME.COLORS.WHITE : null }}>
                                <Icon type="FontAwesome" name="list-alt" style={styles.actionbar_icon} />
                            </TouchableHighlight>
                            <TouchableHighlight underlayColor={false} onPress={() => this.onViewAction('grid')} style={{ ...styles.actionbar_icon_btn, backgroundColor: this.state.view === 'grid' ? THEME.COLORS.WHITE : null }}>
                                <Icon type="Entypo" name="grid" style={styles.actionbar_icon} />
                            </TouchableHighlight>
                            <TouchableHighlight underlayColor={false} onPress={() => this.onViewAction('list')} style={{ ...styles.actionbar_icon_btn, backgroundColor: this.state.view === 'list' ? THEME.COLORS.WHITE : null }}>
                                <Icon type="Entypo" name="list" style={styles.actionbar_icon} />
                            </TouchableHighlight>
                        </View>
                    </View>
                    <View style={{ flex: 1, marginTop: 10 }}>
                        {
                            this.state.view === 'post' &&
                            <ScrollView contentContainerStyle={{ paddingBottom: 60 }} showsVerticalScrollIndicator={false}>
                                <PostCard onPostPress={this.onPostPress} onBtnPress={this.onPostPress} view={this.state.view} images={this.state.images} varients={this.state.varient} />
                                <PostCard onPostPress={this.onPostPress} onBtnPress={this.onPostPress} view={this.state.view} images={this.state.images} varients={this.state.varient} />
                            </ScrollView>
                        }
                        {
                            this.state.view === 'list' &&
                            <SwipeListView
                                data={[1, 2, 3, 4, 5, 6, 7, 8, 9]}
                                renderItem={(p) => <ListPost {...p} />}
                                keyExtractor={(item, index) => index}
                                renderHiddenItem={(data, rowMap) => (
                                    <View style={styles.swipe_delete_container}>
                                        <TouchableHighlight underlayColor={false} onPress={() => alert("hey")} style={styles.star_btn_container} >
                                            <>
                                                <Icon type="AntDesign" name="star" style={{ color: THEME.COLORS.WHITE }} />
                                                <Text style={{ color: THEME.COLORS.WHITE }}>SAVE</Text>
                                            </>
                                        </TouchableHighlight>
                                        <TouchableHighlight underlayColor={false} onPress={() => alert("hey")} style={styles.delete_btn_container} >
                                            <>
                                                <Icon type="FontAwesome" name="mail-forward" style={{ color: THEME.COLORS.WHITE }} />
                                                <Text style={{ color: THEME.COLORS.WHITE }}>SHARE</Text>
                                            </>
                                        </TouchableHighlight>
                                        <TouchableHighlight underlayColor={false} onPress={() => alert("hey")} style={styles.star_btn_container} >
                                            <>
                                                <Icon type="Octicons" name="sync" style={{ color: THEME.COLORS.WHITE }} />
                                                <Text style={{ color: THEME.COLORS.WHITE }}>SWAP</Text>
                                            </>
                                        </TouchableHighlight>
                                    </View>
                                )}
                                rightOpenValue={-225}
                                disableRightSwipe={true}
                                keyExtractor={(item, index) => index}
                                showsVerticalScrollIndicator={false}
                            />
                        }
                        {
                            this.state.view === 'grid' &&
                            <FlatList
                                data={[1, 2, 3, 4, 5, 6, 7, 8, 9]}
                                renderItem={(p) => <GridPost {...p} />}
                                keyExtractor={(item, index) => index}
                                numColumns={2}
                                key={2}
                                showsVerticalScrollIndicator={false}
                            />
                        }
                    </View>
                </View>
            </ImageLayout >
        )
    }
}

export default HomeScreen;