import React, { Component } from "react";
import { View, Text, StyleSheet, Image, ScrollView, Dimensions } from "react-native";
import ImageLayout from "../../../components/bglayout";
import { THEME } from "../../../themes/default";
import { FlatList } from "react-native-gesture-handler";
import { STRING } from "../../../utils/strings";
import { styles } from "./style";

class TrendingScreen extends Component {

    state = {
        brands: [
            {
                name: "Nike",
                image: require("./../../../assets/images/shoes/nike.jpg")
            },
            {
                name: "Air Jordan",
                image: require("./../../../assets/images/shoes/air.jpg")
            },
            {
                name: "Reebok",
                image: require("./../../../assets/images/shoes/reebok.jpg")
            },
            {
                name: "Adidas",
                image: require("./../../../assets/images/shoes/adidas.jpg")
            },
            {
                name: "Woodland",
                image: require("./../../../assets/images/shoes/woodland.jpg")
            },
            {
                name: "Skechers",
                image: require("./../../../assets/images/shoes/skechers.jpg")
            },
            {
                name: "Puma",
                image: require("./../../../assets/images/shoes/puma.jpeg")
            }
        ]
    }

    space() {
        return (<View style={{ height: 50, width: 20 }} />)
    }

    brandListItemRender = (p) => {
        return (
            <View style={{ flexDirection: 'column', alignItems: 'center' }}>
                <Image style={{ resizeMode: 'cover', width: 80, height: 80, borderRadius: 15 }} source={p.item.image} />
                <Text style={{ fontWeight: 'bold', fontSize: 15, color: THEME.COLORS.GREY, marginTop: 10 }}>{p.item.name}</Text>
            </View>
        )
    }

    render() {
        return (
            <ImageLayout>
                <View style={styles.container}>
                    <ScrollView contentContainerStyle={{ paddingBottom: 60 }} showsVerticalScrollIndicator={false}>
                        <View style={styles.brand_container}>
                            <Text style={styles.brand_text}>{STRING.BRANDS}</Text>
                            <FlatList
                                ItemSeparatorComponent={this.space}
                                data={this.state.brands}
                                renderItem={(p) => this.brandListItemRender(p)}
                                horizontal={true}
                                showsHorizontalScrollIndicator={false}
                                style={{
                                    marginTop: 15
                                }}
                                keyExtractor={(item, index) => index}
                            />
                        </View>
                        <View style={styles.brand_container}>
                            <Text style={styles.brand_text}>{STRING.TRENDING}</Text>

                            <View style={styles.section_trending_container}>
                                <View style={{ flex: 1 }}>
                                    <Image
                                        style={styles.trending_big_image}
                                        resizeMode="cover"
                                        source={require("./../../../assets/images/shoes/nike.jpg")}
                                    />
                                    <Text style={styles.label}>TRAVIS SCOTT X AIR MAX 270 REACT ENG 'CACTUS TRAILS'</Text>
                                </View>
                                <View style={styles.short_image_container}>
                                    <View style={styles.short_single_image_card_left}>
                                        <Image
                                            style={styles.short_image}
                                            resizeMode="cover"
                                            source={require("./../../../assets/images/shoes/puma.jpeg")}
                                        />
                                        <Text style={styles.label}>TRAVIS SCOTT X AIR MAX 270</Text>
                                    </View>
                                    <View style={styles.short_single_image_card_right}>
                                        <Image
                                            style={styles.short_image}
                                            resizeMode="cover"
                                            source={require("./../../../assets/images/shoes/woodland.jpg")}
                                        />
                                        <Text style={styles.label}>TRAVIS SCOTT X AIR MAX 270</Text>
                                    </View>
                                </View>
                            </View>

                        </View>
                    </ScrollView>
                </View>
            </ImageLayout>
        )
    }
}



export default TrendingScreen;