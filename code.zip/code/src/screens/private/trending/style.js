import { StyleSheet, Dimensions } from "react-native"
import { THEME } from "../../../themes/default"

const { width } = Dimensions.get('window')
export const styles = StyleSheet.create({
    container: {
        flex: 1,
        margin: 15
    },
    brand_container: {
        paddingTop: 20
    },
    brand_text: {
        fontSize: 18,
        fontWeight: 'bold',
        color: THEME.COLORS.GREY
    },
    label: {
        fontSize: 20,
        color: THEME.COLORS.GREY,
        fontWeight: 'bold',
        marginTop: 20
    },
    section_trending_container: { flex: 1, marginTop: 20 },
    trending_big_image: { width: "100%", height: 300, borderRadius: 20 },
    short_image_container: { flexDirection: 'row', marginTop: 30, justifyContent: 'space-between' },
    short_single_image_card_left: { flex: 1, alignItems: 'flex-start' },
    short_single_image_card_right: { flex: 1, alignItems: 'flex-end' },
    short_image: { width: '93%', height: 180, borderRadius: 20 }
})
