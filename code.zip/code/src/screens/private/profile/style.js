import { StyleSheet, Dimensions } from "react-native"
import { THEME } from "../../../themes/default";

const { width, height } = Dimensions.get('window');
export const styles = StyleSheet.create({
    container: {
        flex: 1
    },
    image: {
        width: width,
        height: 200,
    },
    thumbnail: {
        width: 80,
        height: 80,
        borderRadius: 50
    },
    section_profile_detail: {
        marginLeft: 15,
        marginRight: 15,
        marginTop: 20,
        flexDirection: 'row'
    },
    thumbnail_container: {
        height: 80
    },
    pluscircle: {
        position: 'absolute',
        right: -7,
        bottom: -7,
        color: THEME.COLORS.GREY,
    },
    section_username: {
        marginTop: 20,
        flexDirection: "row",
        justifyContent: 'space-between',
        marginLeft: 15,
        marginRight: 15,
        alignItems: 'center'
    },
    username_text: {
        color: THEME.COLORS.GREY,
        fontSize: 20,
        fontWeight: 'bold'
    },
    username_location: {
        color: THEME.COLORS.GREY,
        fontSize: 18
    },
    btn_container: {
        margin: 15,
        marginTop: 25
    },
    main_section_title: {
        margin: 15,
        flexDirection: 'row',
        alignItems: 'center'
    },
    text_grails: {
        fontSize: 17,
        fontWeight: 'bold',
        color: THEME.COLORS.GREY
    },
    text_see_list: {
        fontSize: 17,
        color: THEME.COLORS.GREY,
        paddingLeft: 10,
        paddingRight: 10,
        paddingTop: 5,
        paddingBottom: 5,
        borderWidth: 1,
        marginLeft: 20,
        borderRadius: 40
    },
    main_section_logo: {
        margin: 15,
        flexDirection: 'row'
    },
    logo_title: {
        flex: 1,
        marginLeft: 20,
        justifyContent: 'center'
    },
    logo_title_text: {
        fontSize: 17,
        fontWeight: 'bold',
        color: THEME.COLORS.GREY
    },
    gallary_container: {
        flex: 1
    }
})