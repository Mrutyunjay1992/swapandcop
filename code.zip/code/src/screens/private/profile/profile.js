import React, { Component } from "react";
import { View, Text, StyleSheet, Image, Dimensions, FlatList } from "react-native";
import { Thumbnail, Icon } from "native-base";
import ImageLayout from "../../../components/bglayout";
import { THEME } from "../../../themes/default";
import UserDetail from "../../../components/details";
import { ScrollView } from "react-native-gesture-handler";
import Button from "../../../components/button";
import { STRING } from "../../../utils/strings";
import Logo from "../../../components/logo";
import { styles } from "./style";

class ProfileScreen extends Component {



    flatListRenderItem = (props) => {
        return (

            <View style={{ flex: 1, alignItems: 'center', marginTop: 10 }}>
                <Image
                    style={{ width: 130, height: 120, borderRadius: 10 }}
                    resizeMode={'cover'}   /* <= changed  */
                    source={require("./../../../assets/images/placeholder.jpeg")}
                />
            </View>
        )
    }

    render() {
        const uri = "https://facebook.github.io/react-native/docs/assets/favicon.png";
        return (
            <ImageLayout>
                <View style={styles.container}>
                    <ScrollView contentContainerStyle={{ paddingBottom: 60 }} showsVerticalScrollIndicator={false}>
                        <View>
                            <Image
                                style={styles.image}
                                resizeMode={'cover'}   /* <= changed  */
                                source={require("./../../../assets/images/shoes/puma.jpeg")}
                            />
                        </View>

                        <View style={styles.section_profile_detail}>
                            <View style={styles.thumbnail_container}>
                                <Thumbnail style={styles.thumbnail} source={require("./../../../assets/images/user-placeholder.png")} />
                                <Icon type="AntDesign" name="pluscircle" style={styles.pluscircle} />
                            </View>
                            <UserDetail />
                        </View>
                        <View style={styles.section_username}>
                            <View>
                                <Text style={styles.username_text}>GOATKicks</Text>
                                <Text style={styles.username_location}>Atlanta, GA</Text>
                            </View>
                            <Icon type="FontAwesome" name="gear" style={styles.gear_icon} />
                        </View>
                        <View style={styles.btn_container}>
                            <Button
                                containerStyle={styles.create_new_ac}
                                text={STRING.EDIT_PROFILE}
                                iconStyle={{ color: THEME.COLORS.WHITE, position: "absolute", right: 110, fontSize: 17 }}
                                iconType={'FontAwesome'}
                                iconName={'pencil'}
                                textStyle={styles.socail_media_btn_text}
                                onPress={() => true}
                            />
                        </View>
                        <View style={styles.main_section_title}>
                            <Text style={styles.text_grails}>{STRING.GRAILS}</Text>
                            <Text style={styles.text_see_list}>{STRING.SEE_LIST}</Text>
                        </View>
                        <View style={styles.main_section_logo}>
                            <Logo />
                            <View style={styles.logo_title}>
                                <Text style={styles.logo_title_text}>TRAVIS SCOTT x AIR MAX 270 REACT ENG 'CACTUS TRAILS</Text>
                            </View>
                        </View>

                        <View style={styles.gallary_container}>
                            <FlatList
                                data={[1, 2, 3, 4, 5, 6, 7, 8, 9]}
                                renderItem={(p) => this.flatListRenderItem(p)}
                                keyExtractor={(item, index) => index}
                                numColumns={3}
                                key={3}
                            />
                        </View>
                    </ScrollView>
                </View>
            </ImageLayout>
        )
    }
}


export default ProfileScreen