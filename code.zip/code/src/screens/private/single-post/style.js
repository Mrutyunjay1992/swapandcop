import { StyleSheet } from "react-native"
import { THEME } from "../../../themes/default"

export const styles = StyleSheet.create({

    btn_container: {
        margin: 10
    },
    specification_table: {
        marginTop: 20
    },
    specification_table_item_container_text: {
        fontSize: 15,
        fontWeight: '500',
        color: THEME.COLORS.GREY
    },
    specification_table_item_container_detail: {
        flex: 1,
        justifyContent: 'center'
    },
    specification_table_item_container_icon_text: {
        color: THEME.COLORS.WHITE,
        backgroundColor: THEME.COLORS.GREY,
        width: 50,
        height: 50,
        borderRadius: 50,
        justifyContent: 'center',
        alignItems: 'center',
        textAlign: 'center',
        textAlignVertical: 'center',
        fontSize: 12
    },
    specification_table_item_container_icon_text_heading: {
        fontWeight: 'bold',
        fontSize: 16,
        color: THEME.COLORS.GREY,
        marginLeft: 10
    },
    specification_table_item_container_icon: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center'
    },
    specification_table_item_container: {
        flex: 1,
        flexDirection: 'row',
        borderTopColor: THEME.COLORS.GREY_LIGHT,
        borderTopWidth: 1,
        paddingTop: 15,
        paddingBottom: 15
    },
    specification: {
        flex: 1,
        marginTop: 20,
        marginBottom: 20
    },
    product_detail: {
        fontWeight: '500',
        fontSize: 20,
        color: THEME.COLORS.GREY,
    },
    section_slider: {
        height: 300,
        marginTop: 15
    },
    container: {
        marginLeft: 15,
        marginRight: 15,
        flex: 1
    },
    count: { position: 'absolute', left: 15, top: 15, backgroundColor: THEME.COLORS.GREY_LIGHT, padding: 4, borderRadius: 10, color: THEME.COLORS.WHITE },
    right_star: { position: 'absolute', right: 15, top: 15, backgroundColor: THEME.COLORS.GREY_LIGHT, padding: 4, borderRadius: 100 / 2 },
    section_detail: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginTop: 10
    },
    desc: {
        width: '70%'
    },
    detail_text: {
        fontSize: 20,
        fontWeight: 'bold',
        color: THEME.COLORS.GREY
    },
    rate: {
        width: '30%',
        alignItems: 'flex-end'
    },
    section_header: {
        flexDirection: 'row',
        marginTop: 20
    },
    thumbnail: {
        width: 50,
        height: 50
    },
    header_username_section: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center'
    },
    header_username: {
        marginLeft: 15
    },
    username: {
        fontSize: 18,
        fontWeight: 'bold',
        color: THEME.COLORS.GREY,
        marginRight: 15
    },
})