import React, { Component } from "react";
import { View, Text, StyleSheet, Dimensions } from "react-native";
import { SliderBox } from "react-native-image-slider-box";
import { Thumbnail, Icon } from "native-base";
import { ScrollView } from "react-native-gesture-handler";
import { AirbnbRating } from 'react-native-ratings';
import { THEME } from "../../../themes/default";
import ImageLayout from "../../../components/bglayout";
import { styles } from "./style";
import Button from "../../../components/button";
import { STRING } from "../../../utils/strings";

class SinglePost extends Component {

    state = {
        images: [
            require("./../../../assets/images/shoes/adidas.jpg"),
            require("./../../../assets/images/shoes/air.jpg"),
            require("./../../../assets/images/shoes/puma.jpeg"),
        ],

    }


    onBtnPress = () => {
        this.props.navigation.navigate('chatscreen')
    }

    render() {
        return (
            <ImageLayout>
                <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
                    <View style={styles.section_detail}>
                        <View style={styles.desc}>
                            <Text style={styles.detail_text}>Travis Scott x air Max 270 React Eng 'Cactus Trails'</Text>
                        </View>
                        <View style={styles.rate}>
                            <Text style={styles.detail_text}>$500/ea</Text>
                        </View>
                    </View>

                    {/* Slider START */}
                    <View style={styles.section_slider}>
                        <SliderBox
                            images={this.state.images}
                            inactiveDotColor="#90A4AE"
                            paginationBoxVerticalPadding={20}
                            resizeMethod={'resize'}
                            resizeMode={'cover'}
                            ImageComponentStyle={{ borderRadius: 15, width: '97%', marginTop: 5, height: 300, width: Dimensions.get('window').width - 30 }}
                            imageLoadingColor="#2196F3"
                        />
                        {/* Count Image START*/}
                        <Text style={styles.count}>1/{this.state.images.length}</Text>
                        {/* Count Image END*/}
                        {/* star Icon START */}
                        <View style={styles.right_star}>
                            <Icon type="Entypo" name={'star'} style={{ color: THEME.COLORS.WHITE }} />
                        </View>
                        {/* star Icon END */}
                    </View>
                    {/* Slider START */}



                    {/* user detail START */}
                    <View style={styles.section_header}>
                        <View style={styles.header_avatar}>
                            <Thumbnail style={styles.thumbnail} source={require("./../../../assets/images/user-placeholder.png")} />
                        </View>
                        <View style={styles.header_username_section}>
                            <View style={styles.header_username}>
                                <View style={{ flexDirection: 'row' }}>
                                    <Text style={styles.username}>Pavanwind</Text>
                                    <AirbnbRating
                                        count={5}
                                        reviews={["Terrible", "Bad", "Meh", "OK", "Good"]}
                                        defaultRating={5}
                                        size={10}
                                        showRating={false}
                                        selectedColor={THEME.COLORS.GREY}
                                    />
                                </View>
                                <Text style={styles.location}>Atlanta,GA</Text>
                            </View>
                            <View>
                                <Icon style={{ fontSize: 30, color: THEME.COLORS.GREY_LIGHT }} type={'MaterialIcons'} name={'more-horiz'} />
                            </View>
                        </View>
                    </View>
                    {/* user detail END */}


                    <View style={styles.specification}>
                        <Text style={styles.product_detail}>
                            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in
                        </Text>
                    </View>

                    <View style={styles.specification_table}>

                        <View style={styles.specification_table_item_container}>
                            <View style={styles.specification_table_item_container_icon}>
                                <Text style={styles.specification_table_item_container_icon_text}>ICON</Text>
                                <Text style={styles.specification_table_item_container_icon_text_heading}>SIZE</Text>
                            </View>
                            <View style={styles.specification_table_item_container_detail}>
                                <Text style={styles.specification_table_item_container_text}>M8 Pair / M10.5 Pair</Text>
                                <Text style={styles.specification_table_item_container_text}>M8 Pair / M10.5 Pair</Text>
                            </View>
                        </View>

                        <View style={styles.specification_table_item_container}>
                            <View style={styles.specification_table_item_container_icon}>
                                <Text style={styles.specification_table_item_container_icon_text}>ICON</Text>
                                <Text style={styles.specification_table_item_container_icon_text_heading}>Condition</Text>
                            </View>
                            <View style={{ ...styles.specification_table_item_container_detail, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                                <AirbnbRating
                                    count={5}
                                    reviews={["Terrible", "Bad", "Meh", "OK", "Good"]}
                                    defaultRating={5}
                                    size={15}
                                    showRating={false}
                                    selectedColor={THEME.COLORS.GREY}
                                />
                                <Text style={{ ...styles.specification_table_item_container_text, marginRight: 10 }}>5 Star</Text>
                            </View>
                        </View>

                        <View style={styles.specification_table_item_container}>
                            <View style={styles.specification_table_item_container_icon}>
                                <Text style={styles.specification_table_item_container_icon_text}>ICON</Text>
                                <Text style={styles.specification_table_item_container_icon_text_heading}>Quantity</Text>
                            </View>
                            <View style={styles.specification_table_item_container_detail}>
                                <Text style={styles.specification_table_item_container_text}>I have Multiple sizes available</Text>
                            </View>
                        </View>

                        <View style={styles.specification_table_item_container}>
                            <View style={styles.specification_table_item_container_icon}>
                                <Text style={styles.specification_table_item_container_icon_text}>ICON</Text>
                                <Text style={styles.specification_table_item_container_icon_text_heading}>Wear & Tear</Text>
                            </View>
                            <View style={styles.specification_table_item_container_detail}>
                                <Text style={styles.specification_table_item_container_text}>Lightly Worn</Text>
                            </View>
                        </View>


                        <View style={styles.specification_table_item_container}>
                            <View style={styles.specification_table_item_container_icon}>
                                <Text style={styles.specification_table_item_container_icon_text}>ICON</Text>
                                <Text style={styles.specification_table_item_container_icon_text_heading}>Check Id #</Text>
                            </View>
                            <View style={styles.specification_table_item_container_detail}>
                                <Text style={styles.specification_table_item_container_text}>#xxxxxx</Text>
                            </View>
                        </View>
                    </View>


                </ScrollView>
                <View style={styles.btn_container}>
                    <Button
                        text={STRING.LETS_SWAP}
                        iconStyle={{ color: THEME.COLORS.WHITE, position: "absolute", right: 10 }}
                        iconType={'AntDesign'}
                        iconName={'arrowright'}
                        textStyle={styles.socail_media_btn_text}
                        onPress={() => this.onBtnPress()}
                    />
                </View>
            </ImageLayout>
        )
    }
}



export default SinglePost;