import React, { Component } from "react";
import { View, Text, StyleSheet } from "react-native";
import { ScrollView, TouchableHighlight, FlatList } from "react-native-gesture-handler";
import { Icon } from "native-base";
import ImageLayout from "../../../components/bglayout";
import { THEME } from "../../../themes/default";
import Button from "../../../components/button";
import { STRING } from "../../../utils/strings";
import DropDown from "../../../components/dropDown";
import Input from "../../../components/input";
import CheckBox from "../../../components/checkbox";



class SaveSearch extends Component {

    state = {
        colors: [
            {
                name: 'WHITE',
                color: '#FFFFFF'
            },
            {
                name: 'RED',
                color: '#FF0000'
            },
            {
                name: 'MAROON',
                color: '#800000'
            },
            {
                name: 'YELLOW',
                color: '#FFFF00'
            },
            {
                name: 'OLIVE',
                color: '#808000'
            },
            {
                name: 'LIME',
                color: '#FF0000'
            },
            {
                name: 'GREEN',
                color: '#008000'
            },
            {
                name: 'AQUA',
                color: '#00FFFF'
            },
            {
                name: 'TEAL',
                color: '#008080'
            },
            {
                name: 'BLUE',
                color: '#0000FF'
            }
        ]
    }


    sizeNumberList = (props) => {
        return (
            <View style={{ flex: 1, width: 50, height: 50, justifyContent: 'center', alignItems: 'center', margin: 3, backgroundColor: (props.item === 12 || props.item === 10) ? THEME.COLORS.GREY_LIGHT : THEME.COLORS.WHITE }}>
                <Text style={{ fontSize: 18, }}>{props.item}</Text>
            </View>
        )
    }


    flatListColorRender = (props) => {
        return (
            <View style={{ flex: 1, width: 70, height: 70, justifyContent: 'center', alignItems: 'center', margin: 3, }}>
                <CheckBox status={true} style={{ width: 50, height: 50, padding: 10, backgroundColor: props.item.color ? props.item.color : THEME.COLORS.GREY }} />
                <Text style={{ ...styles.label, fontSize: 13, textAlign: 'center' }}>{props.item.name}</Text>
            </View>
        )
    }

    render() {
        return (
            <ImageLayout>
                <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 20 }}>

                    <View style={styles.input_container}>
                        <Input input={{ placeholder: STRING.ZIP_CODE, value: 'Air Jordan 13 Retro' }} style={{ backgroundColor: THEME.COLORS.WHITE, borderColor: THEME.COLORS.BLACK }} />
                        <Button
                            containerStyle={{ marginTop: 20 }}
                            text={STRING.MAKE_IT_A_GRIL}
                            textStyle={styles.socail_media_btn_text}
                            onPress={() => this.props.navigation.navigate('savesearches')}
                        />

                        <DropDown placeholder="All Brands" style={{ width: '100%' }} />
                        <DropDown placeholder="All Shoes" style={{ width: '100%' }} />
                        <Input input={{ placeholder: STRING.ZIP_CODE }} style={{ backgroundColor: THEME.COLORS.WHITE, borderColor: THEME.COLORS.BLACK }} />
                    </View>

                    <View style={styles.size_container}>
                        <View style={styles.section_title}>
                            <Text style={styles.rating_title_text}>{STRING.SIZE}</Text>
                            <DropDown style={{ width: 150 }} placeholder={"Mens (M)"} />
                        </View>
                        <View style={styles.size_numbers_list}>
                            <FlatList
                                data={[4, 4.5, 5.5, 6, 6.5, 7, 7.5, 8, 8.5, 9, 9.5, 10, 10.5, 11, 11.5, 12, 12.5, 13, 13.5, 14, 14.5, 15]}
                                renderItem={(p) => this.sizeNumberList(p)}
                                keyExtractor={(item, index) => index}
                                numColumns={7}
                                key={7}
                            />
                        </View>
                    </View>

                    <View style={styles.distance_container}>
                        <Text style={styles.label}>{STRING.DISTANCE}</Text>
                        <DropDown placeholder="10 Miles" style={{ width: '100%', marginTop: 5 }} />
                    </View>

                    <View style={styles.distance_container}>
                        <Text style={styles.label}>{STRING.PRICE}</Text>
                        <View style={styles.price_container}>
                            <Input input={{ placeholder: STRING.ZERO_RATE }} style={{ backgroundColor: THEME.COLORS.WHITE, borderColor: THEME.COLORS.BLACK, flex: 1, marginTop: 0 }} />
                            <View style={{ flex: 1, borderWidth: 1, height: 1, marginLeft: 10, marginRight: 10, borderColor: THEME.COLORS.GREY_LIGHT }} />
                            <Input input={{ placeholder: STRING.ZERO_RATE }} style={{ backgroundColor: THEME.COLORS.WHITE, borderColor: THEME.COLORS.BLACK, flex: 1, marginTop: 0 }} />
                        </View>
                        <View style={styles.checkbox_container}>
                            <CheckBox status={true} />
                            <Text style={{ ...styles.label, fontSize: 18, fontWeight: 'bold', marginLeft: 20 }}>Show Under Retail (MSRP)</Text>
                        </View>
                    </View>

                    <View style={styles.colors_container}>
                        <Text style={styles.label}>{STRING.COLOR}</Text>
                        <FlatList
                            data={this.state.colors}
                            renderItem={(p) => this.flatListColorRender(p)}
                            numColumns={5}
                            key={5}
                            style={{ marginTop: 20 }}
                        />
                    </View>


                    <View style={styles.condition_container}>
                        <View style={styles.checkbox_container}>
                            <CheckBox status={true} />
                            <Text style={{ ...styles.label, fontSize: 18, fontWeight: 'bold', marginLeft: 20 }}>NEW</Text>
                        </View>
                        <View style={styles.checkbox_container}>
                            <CheckBox status={true} />
                            <Text style={{ ...styles.label, fontSize: 18, fontWeight: 'bold', marginLeft: 20 }}>USED</Text>
                        </View>
                    </View>

                </ScrollView>
                <View style={{ margin: 20 }}>
                    <Button
                        containerStyle={styles.create_new_ac}
                        text={STRING.DELETE}
                        textStyle={styles.socail_media_btn_text}
                        onPress={() => true}
                    />
                    <Button
                        containerStyle={{ marginTop: 20 }}
                        text={STRING.SAVE}
                        textStyle={styles.socail_media_btn_text}
                        onPress={() => true}
                    />
                </View>
            </ImageLayout>
        )
    }
}

const styles = StyleSheet.create({
    condition_container: {
        flexDirection: 'row',
        justifyContent: 'space-evenly',
        marginTop: 20
    },
    colors_container: {
        flex: 1,
        marginTop: 30,
        marginRight: 20,
        marginLeft: 20,
    },
    checkbox_container: {
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: 20,
        marginRight: 20,
        marginLeft: 20,
    },
    price_container: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginTop: 10
    },
    distance_container: {
        flex: 1,
        marginRight: 20,
        marginLeft: 20,
        flexDirection: 'column',
        marginTop: 20
    },
    label: {
        fontSize: 20,
        fontWeight: '500',
        color: THEME.COLORS.GREY
    },
    size_numbers_list: {
        flex: 1,
        marginTop: 20
    },
    rating_title_text: {
        fontSize: 18,
        fontWeight: 'bold',
        color: THEME.COLORS.GREY
    },
    section_title: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center'
    },
    size_container: {
        flex: 1,
        margin: 10,
        marginRight: 20,
        marginLeft: 20,
    },
    input_container: {
        marginRight: 20,
        marginLeft: 20,
        marginTop: 10
    },
    header_container: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        backgroundColor: THEME.COLORS.WHITE,
        height: 70,
        alignItems: 'center',
    },
    save_btn: {
        padding: 10,
        borderWidth: 1,
        borderColor: THEME.COLORS.GREY,
        borderRadius: 10,
        marginRight: 20,
        marginLeft: 20,
        fontSize: 15,
        fontWeight: 'bold',
        color: THEME.COLORS.GREY
    },
    icon: {
        padding: 10,
        borderRadius: 10,
        paddingLeft: 18,
        fontSize: 20,
        fontWeight: 'bold',
        color: THEME.COLORS.GREY
    },
    title: {
        fontSize: 20,
        fontWeight: 'bold',
        color: THEME.COLORS.GREY
    }
})

export default SaveSearch;