import React, { Component } from "react";
import { View, Text, StyleSheet, Image, PermissionsAndroid } from "react-native";
import { Icon } from "native-base";
import { TouchableHighlight, ScrollView, FlatList } from "react-native-gesture-handler";
import { AirbnbRating } from 'react-native-ratings';
import ImagePicker from 'react-native-image-picker';
import ImageLayout from "../../../components/bglayout";
import { RadioButton } from 'react-native-paper';
import { THEME } from "../../../themes/default";
import DropDown from "../../../components/dropDown";
import { STRING } from "../../../utils/strings";
import Input from "../../../components/input";
import Button from "../../../components/button";



class CreatePostScreen extends Component {

    state = {
        language: 'Brand',
        featureImage: '',
        radio_buttons: [
            {
                title: 'Lightly Worn',
                chacked: 'checked'
            },
            {
                title: 'Average',
                chacked: 'unchecked'
            },
            {
                title: 'Heavy Use',
                chacked: 'unchecked'
            },
            {
                title: 'With Original Box',
                chacked: 'unchecked'
            },
        ],
        gridImages: [
            {
                imageUrl: ''
            }
        ]
    };

    flatListRenderItem = (props) => {
        console.log(" === ", props)
        return (
            <View style={{ flex: 1, alignItems: 'center', marginTop: 10 }}>
                {
                    props.item.imageUrl !== '' ?
                        <Image
                            style={styles.add_image_container}
                            resizeMode={'cover'}
                            source={{ uri: props.item.imageUrl }}
                        />
                        :
                        <TouchableHighlight onPress={() => this.gridImageAdd()} style={styles.add_image_container} underlayColor={false}>
                            <Icon type="AntDesign" name="plus" style={{ fontSize: 30, color: THEME.COLORS.WHITE }} />
                        </TouchableHighlight>
                }
            </View>
        )
    }

    gridImageAdd = () => {
        const options = {
            title: 'Please Select',
            storageOptions: {
                skipBackup: true,
                path: 'images',
            }
        };
        ImagePicker.showImagePicker(options, (response) => {
            if (response.uri) {
                var newArray = this.state.gridImages;
                newArray.unshift({ imageUrl: response.uri })
                console.log(" ==== image arr === ", newArray)
                this.setState({
                    gridImages: newArray
                })
            }
        });
    }

    radioButtonWithLabe = (props) => {
        return (
            <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center', marginTop: 20 }}>
                <RadioButton
                    value="first"
                    status={props.item.chacked}
                    onPress={() => true}
                />
                <Text style={styles.rating_text}>{props.item.title}</Text>
            </View>
        )
    }

    sizeNumberList = (props) => {
        return (
            <View style={{ flex: 1, width: 50, height: 50, justifyContent: 'center', alignItems: 'center', margin: 3, backgroundColor: (props.item === 12 || props.item === 10) ? THEME.COLORS.GREY_LIGHT : THEME.COLORS.WHITE }}>
                <Text style={{ fontSize: 18, }}>{props.item}</Text>
            </View>
        )
    }


    openCamera = () => {
        const options = {
            title: 'Please Select',
            storageOptions: {
                skipBackup: true,
                path: 'images',
            }
        };
        ImagePicker.showImagePicker(options, (response) => {
            console.log(" ==== ", response)
            if (response.uri) {
                this.setState({
                    featureImage: response.uri
                })
                console.log(" === ", response.uri)
            }
        });
    }

    render() {
        const { featureImage, gridImages } = this.state;
        const image = featureImage ? { uri: featureImage } : require("./../../../assets/images/placeholder.jpeg");
        console.log(" === image === ", image)
        return (
            <ImageLayout>
                <View style={styles.container}>
                    <ScrollView contentContainerStyle={{ paddingBottom: 40 }} showsVerticalScrollIndicator={false}>
                        <View style={styles.camera_section}>
                            <TouchableHighlight onPress={() => this.openCamera()} underlayColor={false}>
                                <Icon type="Feather" name="camera" style={styles.camera_icon} />
                            </TouchableHighlight>
                        </View>
                        <View style={styles.selected_image}>
                            <Image style={styles.feature_image} source={image} />
                        </View>
                        <View style={styles.image_grid_container}>
                            <FlatList
                                data={gridImages}
                                renderItem={(p) => this.flatListRenderItem(p)}
                                keyExtractor={(item, index) => index}
                                numColumns={3}
                                key={3}
                            />
                        </View>
                        <View style={styles.form_container}>
                            <DropDown placeholder={"Brand"} />
                            <DropDown placeholder={"Shoe Type"} />
                            <DropDown placeholder={"Price"} />
                        </View>
                        <View style={styles.rating_container}>
                            <Text style={styles.rating_title_text}>{STRING.CONDITION_RATING}</Text>
                            <View style={styles.rating_star_container}>
                                <AirbnbRating
                                    count={5}
                                    reviews={["Terrible", "Bad", "Meh", "OK", "Good"]}
                                    defaultRating={2}
                                    size={20}
                                    showRating={false}
                                    selectedColor={THEME.COLORS.GREY}
                                />
                                <Text style={styles.rating_text}>4 Star Rating</Text>
                            </View>
                        </View>
                        <View style={styles.radio_container}>
                            <Text style={styles.rating_title_text}>{STRING.WEAR_AND_TEAR}</Text>
                            <FlatList
                                style={{ marginTop: 20 }}
                                data={this.state.radio_buttons}
                                renderItem={(p) => this.radioButtonWithLabe(p)}
                                keyExtractor={(item, index) => index}
                                numColumns={2}
                                key={2}
                            />
                        </View>
                        <View style={styles.size_container}>
                            <View style={styles.section_title}>
                                <Text style={styles.rating_title_text}>{STRING.SIZE}</Text>
                                <DropDown style={{ width: 150 }} placeholder={"Mens (M)"} />
                            </View>
                            <View style={styles.size_numbers_list}>
                                <FlatList
                                    data={[4, 4.5, 5.5, 6, 6.5, 7, 7.5, 8, 8.5, 9, 9.5, 10, 10.5, 11, 11.5, 12, 12.5, 13, 13.5, 14, 14.5, 15]}
                                    renderItem={(p) => this.sizeNumberList(p)}
                                    keyExtractor={(item, index) => index}
                                    numColumns={7}
                                    key={7}
                                />
                            </View>
                        </View>
                        <View style={styles.single_radio_container}>
                            {this.radioButtonWithLabe({ item: { title: "I have More than 1 pair available", chacked: 'checked' } })}
                        </View>
                        <View style={styles.input_container}>
                            <Text style={styles.rating_title_text}>{STRING.CHECKED_ID}</Text>
                            <Input input={{ placeholder: '# XXXXXX' }} />
                        </View>
                        <View style={styles.input_container}>
                            <Text style={styles.rating_title_text}>{STRING.DESCRIPTION}</Text>
                            <Input input={{ style: { width: '100%', height: 120 } }} style={{ height: 120 }} />
                        </View>
                        <View style={styles.button_container}>
                            <Button
                                text={STRING.POST_MY_SHOES}
                                textStyle={styles.socail_media_btn_text}
                                onPress={() => true}
                            />
                        </View>
                    </ScrollView>
                </View>
            </ImageLayout>
        )
    }
}

const styles = StyleSheet.create({
    button_container: {
        flex: 1,
        marginTop: 50,
        marginLeft: 20,
        marginRight: 20
    },
    input_container: {
        flex: 1,
        marginTop: 20,
        marginLeft: 20,
        marginRight: 20
    },
    single_radio_container: {
        flex: 1,
        marginTop: 20,
        marginLeft: 20,
        marginRight: 20
    },
    size_container: {
        flex: 1,
        margin: 20
    },
    section_title: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center'
    },
    size_numbers_list: {
        flex: 1,
        marginTop: 20
    },
    container: {
        flex: 1
    },
    camera_section: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 20
    },
    camera_icon: {
        fontSize: 40,
        padding: 40,
        color: THEME.COLORS.WHITE,
        backgroundColor: THEME.COLORS.GREY,
        borderRadius: 60
    },
    selected_image: {
        flex: 1,
        alignItems: 'center',
        margin: 20
    },
    feature_image: {
        width: "100%",
        height: 300,
        borderRadius: 20
    },
    image_grid_container: {
        flex: 1,
        marginLeft: 20,
        marginRight: 20
    },
    add_image_container: {
        width: 110,
        height: 110,
        borderRadius: 10,
        backgroundColor: THEME.COLORS.GREY_LIGHT,
        alignItems: 'center',
        color: THEME.COLORS.WHITE,
        justifyContent: 'center'
    },
    form_container: {
        flex: 1,
        alignItems: 'center',
        margin: 20
    },
    rating_container: {
        flex: 1,
        marginLeft: 20, marginRight: 20
    },
    rating_title_text: {
        fontSize: 18,
        fontWeight: 'bold',
        color: THEME.COLORS.GREY
    },
    rating_star_container: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginTop: 10
    },
    rating_text: {
        fontSize: 15,
        color: THEME.COLORS.GREY,
    },
    radio_container: {
        flex: 1,
        marginLeft: 20, marginRight: 20, marginTop: 30
    }
})


export default CreatePostScreen;