import React, { Component } from "react";
import { View, Text, Animated } from "react-native";
import { FlatList, TouchableHighlight } from "react-native-gesture-handler";
import { SwipeListView } from 'react-native-swipe-list-view';
import ImageLayout from "../../../components/bglayout";
import Input from "../../../components/input";
import { THEME } from "../../../themes/default";
import ChatCard from "../../../components/chat-card";
import { STRING } from "../../../utils/strings";
import { Icon } from "native-base";
import { styles } from "./style";
// import Animated from "react-native-reanimated";

class ChatListScreen extends Component {
    state = {
        listViewData: Array(20)
            .fill("")
            .map((_, i) => ({ key: `${i}`, text: `item #${i}` })),
        opaCity: new Animated.Value(1),
        value: new Animated.Value(100)
    }

    listAnimation = (value, opaCity) => {
        Animated.parallel([
            Animated.timing(this.state.value, {
                toValue: value,
                duration: 500,
                useNativeDriver: false
            }),
            Animated.timing(this.state.opaCity, {
                toValue: opaCity,
                duration: 500,
                useNativeDriver: false
            })
        ]).start(() => {
            console.log(" === animation === ")
        })
    }

    _onScrollUp = () => {
        this.listAnimation(0, 0);
    }

    _onScrollDown = () => {
        this.listAnimation(100, 1);
    }

    render() {
        const { value, opaCity } = this.state;
        return (
            <ImageLayout>
                <View style={styles.container}>
                    <View style={styles.section_search}>
                        <Input
                            input={{ placeholder: 'Search Messages' }}
                            style={{ backgroundColor: THEME.COLORS.WHITE, paddingRight: 20 }}
                            iconType="AntDesign"
                            iconName="search1"
                            right={true}
                            onIconPress={() => alert("hey")}
                        />
                    </View>
                    <View style={styles.section_list}>
                        <Animated.View style={{ ...styles.header_section, height: value, opacity: opaCity }}>
                            <Text style={styles.product_desc}>BEN & JERRY'S X DUNK LOW SB 'CHUNKY DUNKY'</Text>
                            <View style={styles.section_count}>
                                <Text style={styles.total_message}><Text style={{ ...styles.message_detail, fontSize: 17 }} >10</Text> {STRING.MESSAGES}</Text>
                                <Text style={styles.total_message}><Text style={{ ...styles.message_detail, fontSize: 17 }} >2</Text> {STRING.UNREAD}</Text>
                            </View>
                        </Animated.View>
                        <SwipeListView
                            data={this.state.listViewData}
                            renderItem={(p) => <ChatCard {...p} isindicated={true} />}
                            renderHiddenItem={(data, rowMap) => (
                                <View style={styles.swipe_delete_container}>
                                    <TouchableHighlight underlayColor={false} onPress={() => alert("hey")} style={styles.star_btn_container} >
                                        <>
                                            <Icon type="AntDesign" name="star" style={{ color: THEME.COLORS.WHITE }} />
                                            <Text style={{ color: THEME.COLORS.WHITE }}>STAR</Text>
                                        </>
                                    </TouchableHighlight>
                                    <TouchableHighlight underlayColor={false} onPress={() => alert("hey")} style={styles.delete_btn_container} >
                                        <>
                                            <Icon type="AntDesign" name="delete" style={{ color: THEME.COLORS.WHITE }} />
                                            <Text style={{ color: THEME.COLORS.WHITE }}>DELETE</Text>
                                        </>
                                    </TouchableHighlight>
                                </View>
                            )}
                            rightOpenValue={-150}
                            disableRightSwipe={true}
                            keyExtractor={(item, index) => index}
                            showsVerticalScrollIndicator={false}
                            onScrollBeginDrag={(event) => { this.init = event.nativeEvent.contentOffset.y }}
                            onScrollEndDrag={(event) => { this.init < event.nativeEvent.contentOffset.y ? this._onScrollUp() : this._onScrollDown() }}
                        />
                    </View>
                </View>
            </ImageLayout>
        )
    }
}


export default ChatListScreen;