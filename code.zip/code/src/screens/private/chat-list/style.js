import { StyleSheet } from "react-native";
import { THEME } from "../../../themes/default";



export const styles = StyleSheet.create({
    star_btn_container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        width: 75
    },
    delete_btn_container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        width: 75,
        backgroundColor: THEME.COLORS.GREY,
        borderTopRightRadius: 10,
        borderBottomRightRadius: 10
    },
    product_desc: {
        color: THEME.COLORS.GREY,
        fontSize: 20,
        fontWeight: 'bold',
        marginBottom: 10,
        textAlign: 'center'
    },
    section_count: {
        flexDirection: 'row',
        justifyContent: 'space-evenly',
        width: '100%'
    },
    message_detail: {
        flex: 1,
        flexWrap: 'wrap',
        fontSize: 20,
        fontWeight: 'bold',
        color: THEME.COLORS.GREY
    },
    total_message: {
        justifyContent: 'center',
        alignItems: 'center',
        fontSize: 16,
        color: THEME.COLORS.GREY
    },
    header_section: {
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 20
    },
    swipe_delete_container: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'flex-end',
        justifyContent: 'flex-end',
        marginTop: 10,
        backgroundColor: THEME.COLORS.GREY_LIGHT,
        borderRadius: 10
    },
    container: {
        flex: 1,
        marginRight: 20,
        marginLeft: 20
    },
    section_search: {
        justifyContent: 'center',
        alignItems: 'center'
    },
    section_list: {
        flex: 6,
        marginTop: 20
    }
})