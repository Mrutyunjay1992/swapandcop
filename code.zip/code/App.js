/* eslint-disable prettier/prettier */
import React, { Component } from "react";
import TabNavigation from "./src/navigation/tab.navigation";

console.disableYellowBox = true;

class App extends Component {
  render() {
    return (
      <>
        <TabNavigation {...this.props} />
      </>
    );
  }
}

export default App;
